/* github-adapter.js — /api/posts 를 GitHub 저장소로 대체한다
   ═══════════════════════════════════════════════════════════════════════
   왜 이게 필요한가
   ---------------------------------------------------------------------
   GitHub Pages는 정적 파일만 서빙한다. api/posts.js 같은 서버 함수가 돌지
   않으므로, 그 주소에서는 발행이 통째로 죽는다.

   이 파일은 서버 대신 "저장소 자체"를 글 저장고로 쓴다.
     발행  = posts.json 을 GitHub Contents API 로 커밋
     읽기  = Pages 에 올라간 ./posts.json 을 그냥 fetch

   구현 방식
   ---------------------------------------------------------------------
   news-sync.js 는 한 줄도 고치지 않는다. 대신 window.fetch 를 감싸서
   CFG.endpoint('/api/posts') 로 가는 요청만 가로채고, 서버가 돌려주던 것과
   똑같은 모양의 응답을 만들어 돌려준다. 나머지 요청은 그대로 흘려보낸다.

   그래서 로드 순서가 중요하다:
     sync-config.js  →  github-adapter.js  →  news-sync.js

   설정이 없으면(sync-config.js 에 github 블록이 없으면) 이 파일은 아무 것도
   하지 않고 조용히 빠진다. 즉 Vercel 에 올릴 때는 그대로 둬도 무해하다.

   발행 키
   ---------------------------------------------------------------------
   여기서 쓰는 키는 GitHub fine-grained PAT 이다. 브라우저에만 저장되고
   저장소에는 절대 들어가지 않는다. 권한은 이 저장소 하나의
   Contents: Read and write 만 주면 된다.

   알고 있어야 할 한계
   ---------------------------------------------------------------------
   1) 독자에게 보이기까지 Pages 재빌드 시간이 걸린다 (보통 1~3분).
      pollMs 를 4000 으로 두면 헛돈다. 60000 쯤으로 올릴 것.
   2) posts.json 이 커지면 커밋이 무거워진다. 인라인 첨부(data URI)보다
      img/ 경로를 쓰는 편이 훨씬 낫다. 한도를 넘으면 413 으로 막는다.
   3) 글쓴이 본인은 GitHub API 로 직접 읽으므로 자기 글은 즉시 보인다.
      지연은 독자 쪽에만 생긴다.
   ═══════════════════════════════════════════════════════════════════════ */

(function (global) {
  'use strict';

  var CFG = global.NEWS_SYNC_CONFIG || {};
  var GH = CFG.github || {};

  /* 설정이 없으면 손대지 않는다 — Vercel 배포에서는 이 경로로 빠진다 */
  if (!GH.owner || !GH.repo) return;

  var OWNER = String(GH.owner);
  var REPO = String(GH.repo);
  var BRANCH = GH.branch || 'main';
  var PATH = GH.path || 'posts.json';
  var PUBLIC_URL = GH.publicUrl || ('./' + PATH);
  var ENDPOINT = CFG.endpoint || '/api/posts';
  var MAX_BYTES = GH.maxBytes || 900 * 1024;
  var TIMEOUT = 15000;
  var API = 'https://api.github.com';

  /* 반드시 원본 fetch 를 잡아 둔다. 안 그러면 우리가 씌운 래퍼를 다시 불러
     무한 재귀에 빠진다. */
  var nativeFetch = global.fetch.bind(global);

  /* ── UTF-8 안전 base64 ────────────────────────────────────────────
     btoa 는 Latin-1 만 받는다. 본문이 한글이라 그냥 쓰면 InvalidCharacterError
     가 난다. TextEncoder 로 바이트를 만든 뒤 청크로 끊어 넣는다. */
  function b64encode(str) {
    var bytes = new TextEncoder().encode(str);
    var bin = '';
    var CH = 0x8000;
    for (var i = 0; i < bytes.length; i += CH) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    }
    return btoa(bin);
  }

  function b64decode(b64) {
    var bin = atob(String(b64).replace(/\s+/g, ''));
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  }

  function byteLen(str) { return new TextEncoder().encode(str).length; }

  /* ── 응답 만들기 ──────────────────────────────────────────────────
     news-sync 의 req() 는 status / ok / json 만 본다. 진짜 Response 를
     돌려주면 그쪽 코드는 서버와 구분하지 못한다. */
  function J(status, obj) {
    return new Response(JSON.stringify(obj), {
      status: status,
      headers: { 'content-type': 'application/json; charset=utf-8' }
    });
  }

  function emptyDoc() { return { v: 0, ts: 0, posts: [] }; }

  function parseDoc(text) {
    var d = null;
    try { d = JSON.parse(text); } catch (e) { return emptyDoc(); }
    if (Array.isArray(d)) return { v: 1, ts: 0, posts: d };  // 옛 형식(배열)도 받아 준다
    if (!d || typeof d !== 'object') return emptyDoc();
    return { v: d.v | 0, ts: d.ts || 0, posts: Array.isArray(d.posts) ? d.posts : [] };
  }

  function clone(doc) {
    return { v: doc.v | 0, ts: doc.ts || 0, posts: (doc.posts || []).slice() };
  }

  /* ── GitHub API 호출 ─────────────────────────────────────────────── */
  async function gh(path, opts, token) {
    var o = Object.assign({ cache: 'no-store' }, opts || {});
    o.headers = Object.assign({
      accept: 'application/vnd.github+json',
      'x-github-api-version': '2022-11-28'
    }, o.headers || {});
    if (token) o.headers.authorization = 'Bearer ' + token;

    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = null;
    if (ctrl) {
      o.signal = ctrl.signal;
      timer = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, TIMEOUT);
    }
    try {
      return await nativeFetch(API + path, o);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  function repoPath(sub) {
    return '/repos/' + encodeURIComponent(OWNER) + '/' + encodeURIComponent(REPO) + sub;
  }

  function contentsPath() {
    /* 경로의 슬래시는 살려야 한다 — encodeURIComponent 로 통째로 감싸면 깨진다 */
    return repoPath('/contents/' + PATH.split('/').map(encodeURIComponent).join('/'));
  }

  /* ── 읽기: 인증(글쓴이) ──────────────────────────────────────────
     Contents API 는 1MB 초과 파일의 content 를 비워서 준다. 그때는 sha 로
     Git blob 을 따로 받아 온다(최대 100MB). */
  async function readAuthed(token) {
    var r = await gh(contentsPath() + '?ref=' + encodeURIComponent(BRANCH), {}, token);
    if (r.status === 404) return { sha: null, doc: emptyDoc() };
    if (r.status === 401 || r.status === 403) throw new Error('unauthorized');
    if (!r.ok) throw new Error('HTTP ' + r.status);

    var meta = await r.json();
    var text;
    if (meta.content) {
      text = b64decode(meta.content);
    } else {
      var b = await gh(repoPath('/git/blobs/' + meta.sha), {}, token);
      if (!b.ok) throw new Error('HTTP ' + b.status);
      var bj = await b.json();
      text = b64decode(bj.content || '');
    }
    return { sha: meta.sha, doc: parseDoc(text) };
  }

  /* ── 읽기: 공개(독자) ───────────────────────────────────────────
     토큰이 없는 방문자는 Pages 에 올라간 정적 파일을 읽는다. GitHub API 를
     쓰면 비인증 한도(IP 당 시간당 60회)에 금방 걸리므로 절대 쓰지 않는다. */
  async function readPublic() {
    var url = PUBLIC_URL + (PUBLIC_URL.indexOf('?') < 0 ? '?' : '&') + '_=' + Date.now();
    var r = await nativeFetch(url, { cache: 'no-store' });
    if (r.status === 404) return emptyDoc();
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return parseDoc(await r.text());
  }

  /* ── 쓰기 ────────────────────────────────────────────────────────
     sha 를 같이 보내면 GitHub 이 낙관적 잠금을 걸어 준다. 그 사이 다른
     창이 먼저 썼으면 409/422 가 오고, 우리는 그걸 그대로 409 로 올려
     news-sync 의 기존 충돌 처리에 태운다. */
  async function writeDoc(token, doc, sha, message) {
    var body = {
      message: message,
      content: b64encode(JSON.stringify(doc)),
      branch: BRANCH
    };
    if (sha) body.sha = sha;
    return gh(contentsPath(), {
      method: 'PUT',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body)
    }, token);
  }

  async function conflict(token, fallback) {
    try {
      var fresh = await readAuthed(token);
      return J(409, { ok: false, v: fresh.doc.v | 0, posts: fresh.doc.posts });
    } catch (e) {
      return J(409, { ok: false, v: fallback.v | 0, posts: fallback.posts });
    }
  }

  /* ── GET ─────────────────────────────────────────────────────────── */
  async function handleGet(u, token) {
    var doc;
    try {
      doc = token ? (await readAuthed(token)).doc : await readPublic();
    } catch (e) {
      if (String(e.message) === 'unauthorized') {
        return J(401, { ok: false, error: '키가 맞지 않아요' });
      }
      return J(502, { ok: false, error: String((e && e.message) || e) });
    }
    var v = doc.v | 0;
    var asked = u.searchParams.get('v');
    if (asked !== null && (asked | 0) === v) {
      return J(200, { ok: true, v: v, changed: false, persistent: true });
    }
    return J(200, { ok: true, v: v, posts: doc.posts, persistent: true });
  }

  /* ── GET ?whoami=1 ──────────────────────────────────────────────── */
  async function handleWhoami(token) {
    if (!token) return J(401, { ok: false, error: '키가 필요해요' });
    var r;
    try {
      r = await gh(repoPath(''), {}, token);
    } catch (e) {
      return J(502, { ok: false, error: 'GitHub에 연결하지 못했어요' });
    }
    if (r.status === 401 || r.status === 403) return J(401, { ok: false, error: '키가 맞지 않아요' });
    if (r.status === 404) {
      return J(401, { ok: false, error: '저장소가 안 보여요 — 키의 Repository access 범위를 확인해 주세요' });
    }
    if (!r.ok) return J(502, { ok: false, error: 'HTTP ' + r.status });

    var j = await r.json();
    if (!j.permissions || !j.permissions.push) {
      return J(401, { ok: false, error: '이 키에는 쓰기 권한이 없어요 — Contents: Read and write 로 만들어 주세요' });
    }
    return J(200, { ok: true, persistent: true, login: (j.owner && j.owner.login) || OWNER });
  }

  /* ── POST ────────────────────────────────────────────────────────── */
  async function handlePost(bodyText, token) {
    if (!token) return J(401, { ok: false, error: '발행 권한이 없어요' });

    var body;
    try { body = JSON.parse(bodyText || '{}'); } catch (e) {
      return J(400, { ok: false, error: '요청을 읽지 못했어요' });
    }

    var cur;
    try {
      cur = await readAuthed(token);
    } catch (e) {
      if (String(e.message) === 'unauthorized') return J(401, { ok: false, error: '키가 맞지 않아요' });
      return J(502, { ok: false, error: String((e && e.message) || e) });
    }

    var base = cur.doc;
    var next = clone(base);
    var label;

    if (body.replace && Array.isArray(body.posts)) {
      next.posts = body.posts.slice();
      label = '전체 교체 (' + next.posts.length + '건)';
    } else if (body.post && body.post.id) {
      if (body.ifV !== undefined && (body.ifV | 0) !== (base.v | 0)) {
        return J(409, { ok: false, v: base.v | 0, posts: base.posts });
      }
      var id = body.post.id;
      var i = -1;
      for (var k = 0; k < next.posts.length; k++) {
        if (next.posts[k] && next.posts[k].id === id) { i = k; break; }
      }
      if (i >= 0) next.posts[i] = body.post;
      else next.posts.unshift(body.post);
      label = String(body.post.title || id).slice(0, 60);
    } else {
      return J(400, { ok: false, error: '보낼 글이 없어요' });
    }

    next.v = (base.v | 0) + 1;
    next.ts = Date.now();

    var size = byteLen(JSON.stringify(next));
    if (size > MAX_BYTES) {
      return J(413, {
        ok: false,
        error: '글 묶음이 ' + Math.round(size / 1024) + 'KB라 한도('
          + Math.round(MAX_BYTES / 1024) + 'KB)를 넘었어요 — 인라인 첨부를 img/ 경로로 바꿔 주세요'
      });
    }

    var w;
    try {
      w = await writeDoc(token, next, cur.sha, 'post: ' + label + ' (v' + next.v + ')');
    } catch (e) {
      return J(502, { ok: false, error: 'GitHub에 쓰지 못했어요' });
    }

    if (w.status === 409 || w.status === 422) return conflict(token, base);
    if (w.status === 401 || w.status === 403) return J(401, { ok: false, error: '쓰기 권한이 없어요' });
    if (!w.ok) return J(502, { ok: false, error: 'HTTP ' + w.status });

    return J(200, { ok: true, v: next.v, posts: next.posts, persistent: true });
  }

  /* ── DELETE ?id=… ────────────────────────────────────────────────── */
  async function handleDelete(u, token) {
    if (!token) return J(401, { ok: false, error: '발행 권한이 없어요' });
    var id = u.searchParams.get('id');
    if (!id) return J(400, { ok: false, error: 'id가 없어요' });

    var cur;
    try {
      cur = await readAuthed(token);
    } catch (e) {
      if (String(e.message) === 'unauthorized') return J(401, { ok: false, error: '키가 맞지 않아요' });
      return J(502, { ok: false, error: String((e && e.message) || e) });
    }

    var base = cur.doc;
    var next = clone(base);
    var before = next.posts.length;
    next.posts = next.posts.filter(function (p) { return !p || p.id !== id; });

    /* 이미 없으면 커밋을 만들지 않는다 — 빈 커밋으로 히스토리를 더럽히지 않는다 */
    if (next.posts.length === before) {
      return J(200, { ok: true, v: base.v | 0, posts: base.posts, persistent: true });
    }

    next.v = (base.v | 0) + 1;
    next.ts = Date.now();

    var w;
    try {
      w = await writeDoc(token, next, cur.sha, 'delete: ' + String(id).slice(0, 60) + ' (v' + next.v + ')');
    } catch (e) {
      return J(502, { ok: false, error: 'GitHub에 쓰지 못했어요' });
    }

    if (w.status === 409 || w.status === 422) return conflict(token, base);
    if (w.status === 401 || w.status === 403) return J(401, { ok: false, error: '쓰기 권한이 없어요' });
    if (!w.ok) return J(502, { ok: false, error: 'HTTP ' + w.status });

    return J(200, { ok: true, v: next.v, posts: next.posts, persistent: true });
  }

  /* ── 요청 가로채기 ──────────────────────────────────────────────── */
  var ENDPOINT_PATH = ENDPOINT.split('?')[0];

  function matches(url) {
    if (!url) return false;
    var p = String(url).split('?')[0];
    if (p === ENDPOINT_PATH) return true;
    /* 절대 주소로 들어와도 잡는다 */
    return ENDPOINT_PATH.charAt(0) === '/' && p.length > ENDPOINT_PATH.length
      && p.slice(-ENDPOINT_PATH.length) === ENDPOINT_PATH;
  }

  function headerOf(init, name) {
    var h = init && init.headers;
    if (!h) return '';
    if (typeof h.get === 'function') return h.get(name) || '';
    for (var k in h) {
      if (Object.prototype.hasOwnProperty.call(h, k) && k.toLowerCase() === name) return h[k] || '';
    }
    return '';
  }

  function tokenOf(init) {
    var a = headerOf(init, 'authorization');
    return /^Bearer\s+/i.test(a) ? a.replace(/^Bearer\s+/i, '').trim() : '';
  }

  async function route(url, init) {
    var u;
    try {
      u = new URL(url, global.location ? global.location.href : 'https://example.invalid');
    } catch (e) {
      return J(400, { ok: false, error: 'bad url' });
    }
    var method = String((init && init.method) || 'GET').toUpperCase();
    var token = tokenOf(init);

    if (method === 'OPTIONS') return new Response(null, { status: 204 });
    if (method === 'GET') {
      if (u.searchParams.get('whoami')) return handleWhoami(token);
      return handleGet(u, token);
    }
    if (method === 'POST') return handlePost(init && init.body, token);
    if (method === 'DELETE') return handleDelete(u, token);
    return J(405, { ok: false, error: 'method not allowed' });
  }

  global.fetch = function (input, init) {
    var url;
    try {
      url = typeof input === 'string' ? input
        : (input && typeof input.url === 'string') ? input.url : '';
    } catch (e) { url = ''; }

    if (matches(url)) {
      var opts = init || {};
      /* Request 객체로 들어온 경우 메서드/헤더를 그쪽에서 읽는다 */
      if (typeof input !== 'string' && input && !init) {
        opts = { method: input.method, headers: input.headers };
      }
      return route(url, opts).catch(function (e) {
        return J(502, { ok: false, error: String((e && e.message) || e) });
      });
    }
    return nativeFetch(input, init);
  };

  /* 진단용 — 콘솔에서 상태를 확인할 수 있게 열어 둔다 */
  global.NewsSyncGitHub = {
    owner: OWNER, repo: REPO, branch: BRANCH, path: PATH,
    publicUrl: PUBLIC_URL, maxBytes: MAX_BYTES
  };

})(typeof window !== 'undefined' ? window : this);
