/* sync-config.js — 서버 연동 설정 한 곳
   ─────────────────────────────────────────────────────────────────────
   여기만 고치면 된다. news-sync.js는 이 값을 읽어서 움직인다.
   이 파일이 없거나 enabled를 false로 두면 앱은 예전처럼 완전히 로컬로 동작한다. */

window.NEWS_SYNC_CONFIG = {

  /* 서버 연동을 쓸지. false면 이 파일 이후의 모든 동작이 꺼진다. */
  enabled: true,

  /* 글 저장소 엔드포인트.
     - index.html과 api/를 같은 Vercel 프로젝트에 올렸다면 '/api/posts' 그대로.
     - api만 다른 프로젝트라면 'https://그-프로젝트.vercel.app/api/posts'.
       (그 경우 api 쪽에 ALLOWED_ORIGINS 환경변수를 꼭 넣어야 한다) */
  endpoint: '/api/posts',

  /* 변경 확인 주기(ms). 화면이 보일 때만 돈다.
     서버는 이 요청에 3초 CDN 캐시를 붙이므로, 방문자가 몇이든
     실제 함수 호출은 몇 초에 한 번으로 눌린다.
     Vercel이라면 4000이 적당하다. GitHub Pages는 재빌드에 1~3분이 걸리므로
     4000으로 둬 봐야 같은 파일만 60번 더 받는다. 60000을 권한다. */
  pollMs: 60000,

  /* 탭이 백그라운드일 때의 주기(ms). 0이면 완전히 멈춘다. */
  hiddenPollMs: 0,

  /* 서버로 보낼 인라인 첨부(data URI) 상한.
     이걸 넘는 이미지는 서버로 올라가지 않는다 — 대신 img/ 경로나
     외부 https 주소로 넣으면 크기 제한 없이 그대로 연동된다. */
  maxInlineMediaBytes: 700 * 1024,


  /* ── GitHub Pages 전용 ────────────────────────────────────────────
     이 블록이 있으면 github-adapter.js가 켜지고, /api/posts 대신 저장소의
     posts.json을 글 저장고로 쓴다. Vercel에 올릴 때는 이 블록을 통째로
     지우거나 주석 처리하면 원래대로 서버 함수를 탄다.

     발행 키: GitHub fine-grained PAT
       github.com → Settings → Developer settings
       → Personal access tokens → Fine-grained tokens → Generate new token
       - Repository access : Only select repositories → 이 저장소 하나만
       - Permissions       : Repository permissions → Contents → Read and write
     만든 키는 사이트에서 주소 뒤에 #admin 을 붙여 열리는 창에 넣는다.
     브라우저에만 저장되고 저장소에는 절대 안 들어간다. */
  github: {
    owner:  'aquabluevictory',
    repo:   'elif-suwon-research1',
    branch: 'main',
    path:   'posts.json',

    /* 독자가 읽어 갈 정적 파일 주소. Pages와 같은 폴더면 이대로 둔다. */
    publicUrl: './posts.json',

    /* posts.json 전체 크기 상한. 넘으면 발행이 413으로 막힌다.
       인라인 첨부를 img/ 경로로 바꾸면 이 벽에 안 부딪힌다. */
    maxBytes: 900 * 1024
  },

  /* 발행 키를 이 브라우저에 기억할지. false면 탭을 닫을 때까지만 유지된다. */
  rememberToken: true
};
