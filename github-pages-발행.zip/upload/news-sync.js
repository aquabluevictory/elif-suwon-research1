/* news-sync.js — 서버 정본 ↔ 열려 있는 모든 창
   ═══════════════════════════════════════════════════════════════════════
   지금까지 이 앱의 정본은 "각자의 브라우저"였다. 그래서 글을 쓰면 그 기기에만
   남았고, 남에게 보여 주려면 리더 HTML을 새로 구워 올려야 했다.

   이 파일이 하는 일은 하나다. 정본을 /api/posts로 옮기고, 열려 있는 창들이
   그걸 계속 따라오게 한다.

   ── 흐름 ──────────────────────────────────────────────────────────────
   읽기 : 화면이 보이는 동안 pollMs마다 "버전 바뀌었어?"만 묻는다. 안 바뀌었으면
          응답은 수십 바이트다. 바뀐 순간에만 전체를 받아 화면에 반영한다.
   쓰기 : 발행 키를 가진 창에서만. 게시/수정/삭제가 곧바로 서버로 간다.
          네트워크가 끊겨 있으면 큐에 쌓아 뒀다가 돌아올 때 자동으로 보낸다.
   전파 : 같은 브라우저의 다른 탭에는 BroadcastChannel로 즉시 알린다.

   ── 안 되면 조용히 물러난다 ────────────────────────────────────────────
   /api/posts가 아직 없든, 네트워크가 죽었든, 응답이 이상하든 — 이 파일은
   예외를 밖으로 내보내지 않는다. 그럴 때 앱은 이 파일이 없던 때와 똑같이
   (내장 데이터 또는 로컬 IndexedDB로) 동작한다. 연동이 실패해도 사이트가
   깨지지는 않는다는 뜻이다.

   ── 이 파일이 하지 않는 일 ─────────────────────────────────────────────
   독자의 좋아요·북마크·댓글은 서버로 가지 않는다. 쓰기에는 발행 키가 필요한데
   독자에게는 그 키가 없기 때문이다. 그건 예전과 같이 각자의 브라우저에 남는다.
   ═══════════════════════════════════════════════════════════════════════ */

(function (global) {
  'use strict';

  var CFG = Object.assign(
    {
      enabled: true,
      endpoint: '/api/posts',
      pollMs: 4000,
      hiddenPollMs: 0,
      maxInlineMediaBytes: 700 * 1024,
      rememberToken: true,
      tokenKey: 'news_sync_token_v1',
      queueKey: 'news_sync_queue_v1',
      channel: 'news_sync_v1'
    },
    global.NEWS_SYNC_CONFIG || {}
  );

  /* ── 저장소 shim ──────────────────────────────────────────────────
     appStorage(앱이 위에서 만들어 둔 것)를 우선 쓰고, 없으면 localStorage,
     둘 다 막혀 있으면 메모리로 떨어진다. 어디서 열어도 예외가 안 난다. */
  var mem = {};
  var store = (function () {
    try {
      if (global.appStorage && typeof global.appStorage.getItem === 'function') return global.appStorage;
    } catch (e) {}
    try {
      var ls = global['local' + 'Storage'];
      var probe = '__ns__' + Math.random();
      ls.setItem(probe, '1');
      ls.removeItem(probe);
      return ls;
    } catch (e) {}
    return {
      getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
      setItem: function (k, v) { mem[k] = String(v); },
      removeItem: function (k) { delete mem[k]; }
    };
  })();

  function sget(k) { try { return store.getItem(k); } catch (e) { return null; } }
  function sset(k, v) { try { store.setItem(k, v); } catch (e) {} }
  function sdel(k) { try { store.removeItem(k); } catch (e) {} }

  /* ── 상태 ─────────────────────────────────────────────────────────── */
  var state = {
    v: -1,            // 마지막으로 본 서버 버전 (-1 = 아직 한 번도 못 받음)
    posts: null,      // 마지막으로 받은 목록
    status: 'idle',   // idle | ok | error | offline | off
    lastError: null,
    lastSyncTs: 0,
    persistent: null  // 서버가 진짜 저장소에 붙어 있는지
  };

  var sessionToken = null;   // rememberToken:false일 때 여기에만 둔다
  var onList = null;         // 앱이 등록한 반영 콜백
  var buffered = null;       // 앱이 아직 준비되기 전에 받은 목록
  var timer = null;
  var inFlight = false;
  var bc = null;
  var started = false;

  /* ── 발행 키 ──────────────────────────────────────────────────────── */
  function getToken() {
    if (sessionToken) return sessionToken;
    return sget(CFG.tokenKey) || '';
  }
  function isAdmin() { return !!getToken(); }
  function setToken(t) {
    t = String(t || '').trim();
    if (!t) return;
    if (CFG.rememberToken) sset(CFG.tokenKey, t);
    else sessionToken = t;
  }
  function clearToken() { sessionToken = null; sdel(CFG.tokenKey); }

  function authHeaders(extra) {
    var h = Object.assign({}, extra || {});
    var t = getToken();
    if (t) h['authorization'] = 'Bearer ' + t;
    return h;
  }

  /* ── 서버로 보내기 전 글 다듬기 ────────────────────────────────────
     blob과 세션 한정 참조는 다른 기기에서 의미가 없으므로 떨군다.
     큰 data URI도 떨군다 — 대신 무엇을 떨궜는지 호출부에 알려 준다. */
  var DROP = ['blob', '_draft', '_ref', '_src', '_blob', '_hasBlob'];

  function slim(article) {
    var a = Object.assign({}, article);
    delete a.liked;
    delete a.bookmarked;

    var dropped = null;
    if (a.media && typeof a.media === 'object') {
      var m = Object.assign({}, a.media);
      for (var i = 0; i < DROP.length; i++) delete m[DROP[i]];
      if (m.data && String(m.data).length > CFG.maxInlineMediaBytes) {
        dropped = m.name || '첨부';
        delete m.data;
        if (!m.url && !m.embed) m.unavailable = true;
      }
      if (m.poster && String(m.poster).length > CFG.maxInlineMediaBytes) delete m.poster;
      // blob: URL은 이 세션에서만 유효하다. 다른 기기에서는 깨진 링크가 된다.
      if (m.url && /^blob:/i.test(String(m.url))) delete m.url;
      a.media = m;
    }
    return { post: a, droppedMedia: dropped };
  }

  /* ── 오프라인 큐 ──────────────────────────────────────────────────── */
  function readQueue() {
    try {
      var q = JSON.parse(sget(CFG.queueKey) || '[]');
      return Array.isArray(q) ? q : [];
    } catch (e) { return []; }
  }
  function writeQueue(q) {
    try { sset(CFG.queueKey, JSON.stringify(q.slice(-50))); } catch (e) {}
  }
  function enqueue(op) {
    var q = readQueue();
    // 같은 글에 대한 이전 작업은 최신 것으로 대체한다 — 순서보다 결과가 중요하다
    q = q.filter(function (x) {
      return !(x.op === op.op && ((op.id && x.id === op.id) || (op.post && x.post && x.post.id === op.post.id)));
    });
    q.push(op);
    writeQueue(q);
  }

  async function flushQueue() {
    if (!isAdmin()) return;
    var q = readQueue();
    if (!q.length) return;
    var rest = [];
    for (var i = 0; i < q.length; i++) {
      var op = q[i];
      var ok = false;
      try {
        ok = op.op === 'del' ? await sendRemove(op.id, true) : await sendPush(op.post, true);
      } catch (e) { ok = false; }
      if (!ok) rest = rest.concat(q.slice(i)); // 하나 막히면 나머지는 다음 기회에
      if (!ok) break;
    }
    writeQueue(rest);
  }

  /* ── 네트워크 ─────────────────────────────────────────────────────── */
  async function req(url, opts) {
    var o = Object.assign({ cache: 'no-store', credentials: 'same-origin' }, opts || {});
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    if (ctrl) {
      o.signal = ctrl.signal;
      setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 12000);
    }
    var r = await fetch(url, o);
    var text = await r.text();
    var json = null;
    try { json = JSON.parse(text); } catch (e) {}
    return { status: r.status, ok: r.ok, json: json, text: text };
  }

  function emit(list, reason) {
    state.posts = list;
    state.lastSyncTs = Date.now();
    if (typeof onList === 'function') {
      try { onList(list, reason); } catch (e) {}
    } else {
      buffered = list;
    }
    try {
      global.dispatchEvent(new CustomEvent('newssync:articles', { detail: { posts: list, reason: reason, v: state.v } }));
    } catch (e) {}
    showBadge();
  }

  function showBadge() {
    try {
      var b = document.getElementById('sync-badge');
      if (b) b.hidden = false;
    } catch (e) {}
  }

  /* ── 읽기 ─────────────────────────────────────────────────────────── */
  async function pull(force) {
    if (!CFG.enabled || inFlight) return false;
    inFlight = true;
    try {
      var url = CFG.endpoint + (!force && state.v >= 0 ? (CFG.endpoint.indexOf('?') < 0 ? '?' : '&') + 'v=' + state.v : '');
      var r = await req(url, { method: 'GET' });
      if (!r.ok || !r.json || r.json.ok !== true) {
        // 404 = 아직 배포 안 됨. 조용히 로컬 모드로 산다.
        state.status = r.status === 404 ? 'off' : 'error';
        state.lastError = (r.json && r.json.error) || ('HTTP ' + r.status);
        return false;
      }
      state.status = 'ok';
      state.lastError = null;
      if (r.json.persistent !== undefined) state.persistent = !!r.json.persistent;
      if (r.json.changed === false) return false;   // 바뀐 것 없음
      state.v = r.json.v | 0;
      emit(Array.isArray(r.json.posts) ? r.json.posts : [], 'pull');
      return true;
    } catch (e) {
      state.status = (typeof navigator !== 'undefined' && navigator.onLine === false) ? 'offline' : 'error';
      state.lastError = String((e && e.message) || e);
      return false;
    } finally {
      inFlight = false;
    }
  }

  /* ── 쓰기 ─────────────────────────────────────────────────────────── */
  function applyWriteResult(json) {
    state.v = json.v | 0;
    if (json.persistent !== undefined) state.persistent = !!json.persistent;
    if (Array.isArray(json.posts)) emit(json.posts, 'push');
    broadcast();
  }

  async function sendPush(post, quiet) {
    var r = await req(CFG.endpoint, {
      method: 'POST',
      headers: authHeaders({ 'content-type': 'application/json' }),
      body: JSON.stringify({ post: post, ifV: state.v >= 0 ? state.v : undefined })
    });

    // 다른 창이 먼저 썼다 — 서버 상태를 받아 반영하고 한 번만 다시 시도한다
    if (r.status === 409 && r.json) {
      state.v = r.json.v | 0;
      if (Array.isArray(r.json.posts)) emit(r.json.posts, 'conflict');
      var again = await req(CFG.endpoint, {
        method: 'POST',
        headers: authHeaders({ 'content-type': 'application/json' }),
        body: JSON.stringify({ post: post, ifV: state.v })
      });
      if (again.ok && again.json && again.json.ok) { applyWriteResult(again.json); return true; }
      r = again;
    }

    if (r.ok && r.json && r.json.ok) { applyWriteResult(r.json); return true; }

    if (r.status === 401 || r.status === 503) {
      state.lastError = (r.json && r.json.error) || '발행 권한이 없어요';
      if (!quiet) note(state.lastError);
      return false;             // 권한 문제는 큐에 쌓아도 소용없다
    }
    if (r.status === 413) {
      state.lastError = (r.json && r.json.error) || '내용이 너무 커요';
      if (!quiet) note(state.lastError);
      return false;
    }
    state.lastError = (r.json && r.json.error) || ('HTTP ' + r.status);
    return false;
  }

  async function push(article) {
    if (!CFG.enabled || !isAdmin()) return false;
    var s = slim(article);
    if (s.droppedMedia) {
      note('첨부 «' + s.droppedMedia + '»가 너무 커서 서버로 보내지 않았어요 — img/ 경로나 이미지 주소로 넣으면 그대로 연동돼요');
    }
    try {
      var ok = await sendPush(s.post);
      if (!ok && state.status !== 'off' && !/권한|커요/.test(String(state.lastError || ''))) {
        enqueue({ op: 'put', post: s.post });
        note('지금은 서버에 못 보냈어요 — 연결되면 자동으로 발행됩니다');
      }
      return ok;
    } catch (e) {
      enqueue({ op: 'put', post: s.post });
      note('지금은 서버에 못 보냈어요 — 연결되면 자동으로 발행됩니다');
      return false;
    }
  }

  async function sendRemove(id, quiet) {
    var url = CFG.endpoint + (CFG.endpoint.indexOf('?') < 0 ? '?' : '&') + 'id=' + encodeURIComponent(id);
    var r = await req(url, { method: 'DELETE', headers: authHeaders() });
    if (r.ok && r.json && r.json.ok) { applyWriteResult(r.json); return true; }
    state.lastError = (r.json && r.json.error) || ('HTTP ' + r.status);
    if (!quiet && (r.status === 401 || r.status === 503)) note(state.lastError);
    return false;
  }

  async function remove(id) {
    if (!CFG.enabled || !isAdmin()) return false;
    try {
      var ok = await sendRemove(id);
      if (!ok && state.status !== 'off') enqueue({ op: 'del', id: id });
      return ok;
    } catch (e) {
      enqueue({ op: 'del', id: id });
      return false;
    }
  }

  /* 로컬에 쌓인 글 전체를 서버로 한 번에 올린다 — 첫 이관용 */
  async function replaceAll(list) {
    if (!CFG.enabled || !isAdmin()) return false;
    var posts = (list || []).map(function (a) { return slim(a).post; });
    var r = await req(CFG.endpoint, {
      method: 'POST',
      headers: authHeaders({ 'content-type': 'application/json' }),
      body: JSON.stringify({ posts: posts, replace: true })
    });
    if (r.ok && r.json && r.json.ok) { applyWriteResult(r.json); return true; }
    state.lastError = (r.json && r.json.error) || ('HTTP ' + r.status);
    return false;
  }

  /* ── 탭 사이 전파 ─────────────────────────────────────────────────── */
  function broadcast() {
    try { if (bc) bc.postMessage({ t: 'changed', v: state.v }); } catch (e) {}
  }
  function initChannel() {
    try {
      if (typeof BroadcastChannel === 'undefined') return;
      bc = new BroadcastChannel(CFG.channel);
      bc.onmessage = function (ev) {
        if (ev && ev.data && ev.data.t === 'changed') pull();
      };
    } catch (e) {}
  }

  /* ── 폴링 ─────────────────────────────────────────────────────────── */
  function interval() {
    var hidden = typeof document !== 'undefined' && document.visibilityState === 'hidden';
    return hidden ? (CFG.hiddenPollMs || 0) : (CFG.pollMs || 4000);
  }
  function schedule() {
    clearTimeout(timer);
    var ms = interval();
    if (!ms) return;                       // 백그라운드에서는 완전히 멈춘다
    timer = setTimeout(tick, ms);
  }
  async function tick() {
    if (state.status !== 'off') {
      await pull();
      await flushQueue();
    }
    schedule();
  }
  function wake() {
    if (state.status === 'off') return;
    pull();
    flushQueue();
    schedule();
  }

  function bindDrift() {
    if (typeof document === 'undefined') return;
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') wake(); else schedule();
    });
    global.addEventListener('focus', wake);
    global.addEventListener('online', wake);
  }

  /* ── 알림 ─────────────────────────────────────────────────────────
     앱의 스낵바가 있으면 그걸 쓰고, 없으면 콘솔로 남긴다. */
  function note(msg) {
    try {
      if (typeof global.__newsSnack === 'function') { global.__newsSnack(msg); return; }
    } catch (e) {}
    try { console.info('[news-sync] ' + msg); } catch (e) {}
  }

  /* ── 발행 키 입력 화면 ─────────────────────────────────────────────
     주소 뒤에 #admin을 붙이면 뜬다. 키가 맞으면 이 브라우저에 저장하고
     새로고침한다 — 그때부터 이 창은 글을 쓸 수 있는 창이 된다. */
  function unlockUI() {
    if (document.getElementById('ns-unlock')) return;

    var wrap = document.createElement('div');
    wrap.id = 'ns-unlock';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', 'true');
    wrap.style.cssText =
      'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;' +
      'background:rgba(20,20,22,.55);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);padding:20px;';

    var card = document.createElement('div');
    card.style.cssText =
      'width:100%;max-width:380px;background:#fff;border-radius:16px;padding:22px;' +
      'box-shadow:0 24px 60px rgba(0,0,0,.28);font-family:Inter,system-ui,-apple-system,"Apple SD Gothic Neo",sans-serif;color:#16181d;';

    var admin = isAdmin();
    card.innerHTML =
      '<div style="font-size:17px;font-weight:700;letter-spacing:-.01em">' +
        (admin ? '이 브라우저는 발행 권한이 있어요' : '발행 키') +
      '</div>' +
      '<p style="margin:8px 0 16px;font-size:13.5px;line-height:1.6;color:#5b6068">' +
        (admin
          ? '연필 버튼으로 쓴 글이 곧바로 서버에 올라가고, 열려 있는 모든 창에 몇 초 안에 반영됩니다.'
          : 'Vercel 환경변수 <code style="font-family:ui-monospace,monospace;background:#f1f2f4;padding:1px 5px;border-radius:4px">ADMIN_TOKEN</code>에 넣어 둔 값을 입력하세요. 이 브라우저에만 저장됩니다.') +
      '</p>' +
      (admin ? '' :
        '<input id="ns-key" type="password" autocomplete="off" placeholder="발행 키" ' +
        'style="width:100%;box-sizing:border-box;padding:11px 13px;border:1.5px solid #dcdfe4;border-radius:10px;' +
        'font-size:15px;font-family:inherit;outline:none">') +
      '<div id="ns-msg" style="margin-top:10px;font-size:12.5px;min-height:17px;color:#c0392b"></div>' +
      '<div style="display:flex;gap:8px;margin-top:12px">' +
        '<button id="ns-cancel" type="button" style="flex:1;padding:11px;border:1.5px solid #dcdfe4;background:#fff;' +
          'border-radius:10px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer">닫기</button>' +
        '<button id="ns-go" type="button" style="flex:1;padding:11px;border:0;background:#16181d;color:#fff;' +
          'border-radius:10px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer">' +
          (admin ? '권한 해제' : '확인') + '</button>' +
      '</div>';

    wrap.appendChild(card);
    document.body.appendChild(wrap);

    var msg = card.querySelector('#ns-msg');
    var input = card.querySelector('#ns-key');
    if (input) setTimeout(function () { try { input.focus(); } catch (e) {} }, 60);

    function close() {
      try { wrap.remove(); } catch (e) {}
      if (location.hash === '#admin') {
        try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
      }
    }
    card.querySelector('#ns-cancel').onclick = close;

    card.querySelector('#ns-go').onclick = async function () {
      if (admin) { clearToken(); location.reload(); return; }
      var t = (input.value || '').trim();
      if (!t) { msg.textContent = '키를 입력해 주세요'; return; }
      msg.style.color = '#5b6068';
      msg.textContent = '확인 중…';
      var url = CFG.endpoint + (CFG.endpoint.indexOf('?') < 0 ? '?' : '&') + 'whoami=1';
      try {
        var r = await req(url, { method: 'GET', headers: { authorization: 'Bearer ' + t } });
        if (r.ok && r.json && r.json.ok) {
          setToken(t);
          msg.style.color = '#1e7a4d';
          msg.textContent = r.json.persistent === false
            ? '확인됐어요 — 다만 서버에 저장소가 안 붙어 있어요(임시 저장). 새로고침합니다…'
            : '확인됐어요. 새로고침합니다…';
          setTimeout(function () {
            try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
            location.reload();
          }, 700);
          return;
        }
        msg.style.color = '#c0392b';
        if (r.status === 503) msg.textContent = '서버에 ADMIN_TOKEN이 설정돼 있지 않아요';
        else if (r.status === 404) msg.textContent = '/api/posts를 찾을 수 없어요 — 아직 배포 전인 것 같아요';
        else msg.textContent = '키가 맞지 않아요';
      } catch (e) {
        msg.style.color = '#c0392b';
        msg.textContent = '서버에 연결하지 못했어요';
      }
    };

    if (input) {
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') card.querySelector('#ns-go').click();
      });
    }
    wrap.addEventListener('click', function (e) { if (e.target === wrap) close(); });
  }

  function watchHash() {
    function check() {
      if (location.hash === '#admin' || /[?&]admin(=1)?(&|$)/.test(location.search)) unlockUI();
    }
    global.addEventListener('hashchange', check);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', check);
    else check();
  }

  /* ── 시작 ─────────────────────────────────────────────────────────
     앱(index.html / write.html)이 부팅을 끝낸 뒤 start(cb)를 부른다.
     그 전에 이미 서버 응답이 왔다면 버퍼에 담아 뒀다가 여기서 흘려보낸다. */
  function start(cb) {
    if (typeof cb === 'function') {
      onList = cb;
      if (buffered) { try { cb(buffered, 'buffered'); } catch (e) {} buffered = null; }
    }
    if (started) return;
    started = true;
    initChannel();
    bindDrift();
    watchHash();
    pull(true).then(function () { flushQueue(); schedule(); });
  }

  global.NewsSync = {
    get enabled() { return !!CFG.enabled; },
    get config() { return CFG; },
    get state() { return state; },
    get version() { return state.v; },
    isAdmin: isAdmin,
    setToken: setToken,
    clearToken: clearToken,
    unlock: unlockUI,
    start: start,
    pull: pull,
    push: push,
    remove: remove,
    replaceAll: replaceAll,
    flushQueue: flushQueue
  };

  // 앱 부팅을 기다리지 않고 미리 한 번 당겨 둔다 — 첫 화면이 그만큼 빨리 최신이 된다
  if (CFG.enabled) {
    try { pull(true); } catch (e) {}
  } else {
    state.status = 'off';
  }
})(window);
