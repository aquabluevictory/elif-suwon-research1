# 배포 방법

이 폴더는 그대로 Vercel 프로젝트 루트로 쓸 수 있는 구조예요.

```
index.html       ← 리더 (이미지는 base64 대신 img/ 상대경로 참조)
write.html       ← 글쓰기 (이 기기에 IndexedDB로 저장 + 발행 키가 있으면 서버로도 즉시 발행)
sync-config.js   ← 서버 연동 설정 한 곳 (건드릴 값은 대부분 여기)
news-sync.js     ← index.html·write.html이 공유하는 서버 연동 엔진
img/*.jpg        ← 분리된 기사 이미지 29장
api/market.js    ← 날씨·환율·코스피 통합 프록시 (Edge, 60초 캐시)
api/read.js      ← 기사 원문용 SSRF 방어 프록시 (Node)
api/posts.js     ← 글 정본 저장소 — 발행/수정/삭제를 받아 index.html·write.html에 실시간으로 뿌린다
package.json     ← ESM 선언 ("type":"module") — api/read.js·api/posts.js가 import 구문을 쓴다

github-adapter.js ← GitHub Pages 전용. api/posts.js 없이 저장소 자체를 글 저장고로 쓴다
posts.json        ← 그때 글이 실제로 저장되는 파일
.nojekyll         ← Pages가 Jekyll 빌드를 건너뛰게 한다
```

배포처가 둘이고, 켜지는 경로가 다릅니다.

| | Vercel | GitHub Pages |
|---|---|---|
| 발행 | `api/posts.js` | `github-adapter.js` → `posts.json` 커밋 |
| 독자 반영 | 몇 초 | 1~3분 (Pages 재빌드) |
| 기사 원문 프록시 | 됨 | 안 됨 (공개 CORS 프록시로 폴백) |
| 날씨·환율·코스피 | 서버가 모아 줌 | 브라우저가 직접 가져옴 |
| 발행 키 | `ADMIN_TOKEN` 환경변수 | GitHub fine-grained PAT |

`sync-config.js`의 `github` 블록이 있으면 Pages 경로, 없으면(지우거나 주석 처리하면) Vercel 경로입니다. 두 파일을 다 올려 둬도 서로 방해하지 않아요.

## 1. 배포

Vercel 계정이 있으면 둘 중 하나로 끝나요.

- **대시보드**: 이 폴더를 그대로 드래그해서 [vercel.com/new](https://vercel.com/new)에 올린다.
- **CLI**: 이 폴더에서
  ```
  npm i -g vercel   # 처음 한 번만
  vercel
  ```
  물어보는 대로 엔터 몇 번이면 `https://프로젝트명.vercel.app` 주소가 나와요.

별도 설정 파일(`vercel.json`) 필요 없이 `api/` 폴더만 있으면 자동으로 서버리스 함수로 인식돼요.

## 2. index.html의 `PROXY_BASE` 확인

`index.html`에서 `safeEmbedUrl` 바로 아래 있는 줄:

```js
const PROXY_BASE='';
```

- **같은 프로젝트에 html과 api를 함께 올렸다면** → 빈 문자열 그대로 둔다 (자기 도메인이니까).
- **api만 별도 프로젝트로 올렸다면** → `'https://그-프로젝트.vercel.app'` 처럼 채운다.

## 3. 배포 확인

```
curl https://프로젝트명.vercel.app/api/market
curl "https://프로젝트명.vercel.app/api/read?url=https://example.com"
```

`/api/market`은 `{weather, fx, kospi, ts}` JSON이, `/api/read`는 대상 페이지의 HTML이 그대로 돌아오면 정상이에요.

## 4. 배포 전에도 안 깨짐

`marketFeed()`와 EP의 `self` 항목은 실패하면(아직 배포 전이라 404가 나든, 뭐든) 조용히 기존 direct-fetch·공개 프록시 경로로 넘어가도록 짜여 있어요. 즉 이 폴더를 그냥 로컬에서 `index.html`만 열어 봐도 예전처럼 동작하고, `api/`를 배포하는 순간부터 그 경로를 우선적으로 타기 시작해요.

## 5. api/read.js 남용 방지

이 엔드포인트는 인증이 없다. SSRF는 코드 안에서 막지만, **누가 얼마나 부를 수
있는가**는 별개 문제다. 주소만 알면 누구든 이 함수를 범용 URL 페처로 쓸 수 있고
비용은 이 프로젝트 소유자에게 청구된다. 그래서 두 가지를 넣어 뒀다.

**IP 레이트리밋** — IP당 분당 30회, 인스턴스 전체 분당 300회. 초과하면 `429`와
`Retry-After`를 준다. 한도는 `api/read.js` 상단 상수에서 바꾼다.

한계를 분명히 해 둔다. 이건 인스턴스 메모리 기반이라 서버리스에서는 완전하지 않다.
인스턴스가 여러 개 뜨면 카운터도 여러 벌이고, 콜드스타트마다 초기화된다. 분산
공격은 못 막는다. 확실히 막으려면 Vercel KV나 Upstash 같은 공유 저장소로 옮겨야
한다. 지금 있는 건 실수와 가벼운 남용을 걸러 청구서가 폭주하지 않게 하는
과속방지턱이다.

레이트리밋에 걸려도 사이트는 안 깨진다. `self` 프록시가 실패하면 클라이언트가
공개 프록시로 자동 폴백한다.

**CORS 기본값 변경** — 같은 도메인에 배포했으면(`PROXY_BASE=''`) CORS 헤더가
애초에 필요 없어서, 기본은 헤더를 안 붙인다. `api`만 별도 프로젝트로 올렸다면
Vercel 환경변수를 설정한다.

```
ALLOWED_ORIGINS=https://내-리더-프로젝트.vercel.app
```

쉼표로 여러 개 넣을 수 있다. 설정을 빠뜨리면 브라우저 콘솔에 CORS 오류가 뜨고
리더는 공개 프록시로 폴백한다 — 조용히 망가지지는 않는다.

참고로 오리진·리퍼러 검사는 여기서 쓸 수 없다. 클라이언트가
`referrerPolicy:'no-referrer'`로 호출하는 데다 같은 도메인 GET이라 브라우저가
Origin도 붙이지 않는다. 정상 요청에 헤더가 없으니 헤더로 거르면 사이트 자신이
막힌다. 그리고 curl에서는 어차피 위조가 자유롭다.

## 6. 실시간 글 발행 — write.html ↔ /api/posts ↔ index.html

지금까지는 `write.html`에서 쓴 글이 이 기기의 IndexedDB에만 남았고, 남에게
보여 주려면 "내보내기 → 발행용 HTML 굽기 → index.html로 재배포"를 거쳐야
했다. 이 절부터는 발행이 저장 버튼 한 번으로 끝난다.

### 켜는 법

1. Vercel 프로젝트 환경변수에 **`ADMIN_TOKEN`** 을 추가한다 (아무 문자열이나 —
   `openssl rand -hex 16` 같은 걸로 만들면 충분히 안전하다). 이 값이 없으면
   `/api/posts`는 읽기만 되고 쓰기는 전부 잠긴다 — 열린 채로 죽지 않는다.
2. 다시 배포한다. `sync-config.js`의 `enabled`는 이미 `true`이고 `endpoint`도
   `/api/posts`로 맞춰져 있으니, 같은 프로젝트에 이 폴더를 통째로 올렸다면
   추가로 손댈 값은 없다. `api`만 별도 프로젝트라면 2번 항목의 `PROXY_BASE`처럼
   `sync-config.js`의 `endpoint`를 `'https://그-프로젝트.vercel.app/api/posts'`로
   바꾸고, api 쪽 프로젝트에 `ALLOWED_ORIGINS`도 넣는다.
3. (선택) **영구 저장** — 아무것도 안 하면 글은 서버리스 함수의 인스턴스
   메모리에만 남아 콜드스타트마다 사라진다. Vercel 마켓플레이스에서
   Upstash(또는 Vercel KV)를 프로젝트에 붙이면 `KV_REST_API_URL` /
   `KV_REST_API_TOKEN`(또는 `UPSTASH_REDIS_REST_URL` / `..._TOKEN`)이 자동
   주입되고, `api/posts.js`가 그걸 즉시 집어 써서 영구 저장으로 바뀐다.
   지금 어느 쪽인지는 `curl .../api/posts?diag=1`의 `persistent` 값으로 확인한다.

### 쓰는 법

1. `write.html`을 연다 (예: `https://프로젝트명.vercel.app/write.html`).
2. 주소 뒤에 `#admin`을 붙여 발행 키 입력창을 띄우고, 1번에서 넣은
   `ADMIN_TOKEN` 값을 넣는다. 이 브라우저에 저장되고, 그때부터 이 창은
   저장할 때마다 서버로도 발행하는 창이 된다.
3. 이미 이 기기에 글이 쌓여 있는데 서버는 비어 있으면, 연결 직후
   "지금 가진 N개를 올릴까요?" 스낵바가 뜬다 — 눌러서 한 번에 이관한다.
4. 이후로는 평소처럼 쓰고 저장하면 끝이다. 같은 글이 IndexedDB(이 기기의
   전체 백업)와 서버(공개될 정본) 양쪽에 남는다.

### 리더가 따라오는 법

`index.html`은 화면이 보이는 동안 `sync-config.js`의 `pollMs`(기본 4초)마다
서버에 "버전이 바뀌었는지"만 묻고, 바뀐 순간에만 전체 글 목록을 받아 화면을
새로고침 없이 갱신한다. 이미 열려 있는 리더 탭도 재배포 없이 새 글을 받는다.
서버가 아직 배포 전이거나 잠깐 응답이 없으면 지금 보이는 내장 데이터를 그대로
유지한다 — 화면이 비어 버리는 일은 없다.

### write.html 노출 범위

`/api/posts`의 쓰기는 `ADMIN_TOKEN`으로 막혀 있지만, `write.html` 자체는
URL만 알면 누구나 열 수 있는 평범한 정적 페이지다(토큰이 없으면 그냥
쓰기가 실패할 뿐 페이지는 보인다). 편집 화면을 아예 남에게 보이고 싶지 않다면
Vercel의 **Deployment Protection**(비밀번호 또는 팀 멤버 전용)을 이 경로에
걸거나, `write.html`을 index.html과 다른(비공개) 프로젝트로 분리 배포한다.

### 끄는 법

`sync-config.js`의 `enabled`를 `false`로 바꾸면 이 파일 이후의 모든 동작이
꺼지고 앱은 예전처럼 완전히 로컬로 동작한다. `api/posts.js` 자체를 지워도
되는데, 그 경우 `news-sync.js`는 404를 조용히 로컬 모드로 해석하므로 사이트는
깨지지 않는다.


---

## 5. GitHub Pages만으로 발행하기

Vercel 없이 GitHub 하나로 돌리는 경로예요. 서버 함수가 없으니 **저장소 자체가 DB**가 됩니다. 발행하면 `posts.json`에 커밋이 하나 생기고, Pages가 재빌드되고, 독자는 그 정적 파일을 읽습니다.

### 5.1 발행 키 만들기

github.com → Settings → Developer settings → Personal access tokens → **Fine-grained tokens** → Generate new token

- **Repository access**: Only select repositories → 이 저장소 하나만
- **Permissions**: Repository permissions → **Contents → Read and write**

그 외 권한은 주지 마세요. 이 키로 할 수 있는 일이 이 저장소 파일 쓰기 하나로 묶입니다.

### 5.2 키 넣기

사이트 주소 뒤에 `#admin`을 붙여서 엽니다.

```
https://aquabluevictory.github.io/elif-suwon-research1/write.html#admin
```

창이 뜨면 키를 넣으세요. **키는 그 브라우저에만 저장되고 저장소에는 안 들어갑니다.** 커밋되는 건 `posts.json`뿐이에요.

`sync-config.js`의 `rememberToken`이 `false`면 탭을 닫을 때까지만 유지됩니다.

### 5.3 확인

- 키가 맞으면 "확인됐어요"가 뜨고 새로고침됩니다.
- "저장소가 안 보여요" → 키의 Repository access 범위에 이 저장소가 없어요.
- "쓰기 권한이 없어요" → Contents가 Read-only로 잡혀 있어요.

발행한 뒤 저장소의 커밋 목록에 `post: 제목 (v3)` 같은 커밋이 보이면 정상입니다.

### 5.4 알고 있어야 할 것

**독자에게 보이기까지 1~3분 걸립니다.** Pages 재빌드 시간이에요. 글쓴이 본인은 GitHub API로 직접 읽으므로 자기 글은 바로 보입니다. 지연은 독자 쪽에만 생겨요. 그래서 `pollMs`를 60000으로 잡아 뒀습니다. 4000으로 되돌리면 같은 파일만 60배 더 받게 됩니다.

**인라인 첨부는 피하세요.** `posts.json` 전체가 900KB를 넘으면 발행이 413으로 막힙니다. 이미지는 `img/` 경로나 외부 https 주소로 넣으면 크기 제한 없이 그대로 연동돼요.

**독자는 GitHub API를 안 씁니다.** 비인증 API는 IP당 시간당 60회라 폴링에 못 씁니다. 어댑터는 독자에게 `./posts.json`만 읽히도록 짜여 있어요.

**기사 원문 프록시는 못 살립니다.** `api/read.js`는 요청마다 살아 있는 서버가 필요해서 Pages에서는 대체 불가예요. 기존 공개 CORS 프록시 경로로 조용히 폴백합니다.
